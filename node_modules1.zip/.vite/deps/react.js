import {
  require_react
} from "./chunk-FJB7OZ4R.js";
export default require_react();
//# sourceMappingURL=react.js.map
