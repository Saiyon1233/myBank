export default function getWindow(node: any): any;
