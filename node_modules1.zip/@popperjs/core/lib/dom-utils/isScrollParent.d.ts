export default function isScrollParent(element: HTMLElement): boolean;
