import "./App.css";
import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

export default function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [receiver, setRecevier] = useState("");
  const [addUsername, setAddUsername] = useState("");
  const [addPassword, setAddPassword] = useState("");
  const [deleteUsername, setDeleteUsername] = useState("");
  const [deletePassword, setDeletePassword] = useState("");
  const [currentView, setCurrentView] = useState("login");
  const [balanceArray, setBalanceArray] = useState([0, 1000, 2500]);
  const [usernameArray, setUsernameArray] = useState(["admin", "John", "Bob"]);
  const [passwordArray, setPasswordArray] = useState(["admin", "John", "Bob"]);

  const equal = (username, password) => {
    let equal = false;
    let i = 0;
    for (i = 0; i < usernameArray.length; i++) {
      if (usernameArray[i] === username && passwordArray[i] === password) {
        equal = true;
        break;
      }
    }
    if (username === "admin" && password === "admin") {
      equal = false;
    }
    return equal;
  };

  const deposit = (amount, username) => {
    let currentBalance = parseInt(
      balanceArray[usernameArray.indexOf(username)],
    );
    currentBalance += amount;
    balanceArray[usernameArray.indexOf(username)] = currentBalance;
    alert("Deposited" + " $" + amount + ".00" + " " + "into your account!");
    alert(
      "Your current balance is" +
        " $" +
        balanceArray[usernameArray.indexOf(username)] +
        ".00",
    );
    setDepositAmount("");
  };

  const withdraw = (amount, username) => {
    let currentBalance = parseInt(
      balanceArray[usernameArray.indexOf(username)],
    );
    if (amount <= currentBalance) {
      currentBalance -= amount;
      balanceArray[usernameArray.indexOf(username)] = currentBalance;
      alert("Withdrew" + " $" + amount + ".00" + " " + "from your account!");
      alert(
        "Your current balance is" +
          " $" +
          balanceArray[usernameArray.indexOf(username)] +
          ".00",
      );
    } else {
      alert("You don't have enough money to withdraw that much!");
    }
    setWithdrawAmount("");
  };

  const transfer = (amount, username, receiver) => {
    let currentBalance = parseInt(
      balanceArray[usernameArray.indexOf(username)],
    );
    let receiverBalance = parseInt(
      balanceArray[usernameArray.indexOf(receiver)],
    );

    if (amount <= currentBalance && usernameArray.indexOf(receiver) != -1) {
      currentBalance -= amount;
      receiverBalance += amount;
      balanceArray[usernameArray.indexOf(username)] = currentBalance;
      balanceArray[usernameArray.indexOf(receiver)] = receiverBalance;
      alert(
        "Transferred" +
          " $" +
          amount +
          ".00" +
          " " +
          "to" +
          " " +
          receiver +
          "!",
      );
      alert(
        "Your current balance is" +
          " $" +
          balanceArray[usernameArray.indexOf(username)] +
          ".00",
      );
    } else if (usernameArray.indexOf(receiver) === -1) {
      alert("Unknown user!");
    } else {
      alert("You don't have enough money to transfer that much!");
    }
    setTransferAmount("");
    setRecevier("");
  };

  const login = () => {
    if (equal(username, password)) {
      alert(
        "Welcome" +
          " " +
          username +
          "!" +
          " " +
          "Your current balance is" +
          " $" +
          balanceArray[usernameArray.indexOf(username)] +
          ".00",
      );
      setUsername(username);
      setPassword(password);
      setCurrentView("customer");
    } else if (username === "admin" && password === "admin") {
      alert("Welcome admin!");
      setCurrentView("manager");
    } else {
      alert("Wrong Username or Password!");
    }
  };

  const addCustomer = () => {
    if (balanceArray[usernameArray.indexOf(addUsername)] === -1) {
      setUsernameArray([...usernameArray, addUsername]);
      setPasswordArray([...passwordArray, addPassword]);
      setBalanceArray([...balanceArray, 0]);
      alert("Added" + " " + addUsername + " " + "to the system!");
      setAddUsername("");
      setAddPassword("");
    } else {
      alert("Username already exists!");
    }
  };

  const deleteCustomer = () => {
    if (
      balanceArray[usernameArray.indexOf(deleteUsername)] !== -1 &&
      passwordArray[usernameArray.indexOf(deleteUsername)] === deletePassword
    ) {
      usernameArray.splice(usernameArray.indexOf(deleteUsername), 1);
      passwordArray.splice(usernameArray.indexOf(deleteUsername), 1);
      balanceArray.splice(usernameArray.indexOf(deleteUsername), 1);
      alert("Deleted" + " " + deleteUsername + " " + "from the system!");
      setDeleteUsername("");
      setDeletePassword("");
    } else {
      alert("Wrong Username or Password!");
    }
  };

  return (
    <div>
      {currentView === "login" && (
        <div className="container">
          <div id="loginDiv" class="login">
            <div className="row mt-3">
              <h1>myBank</h1>
            </div>
            <div className="row mt-3">
              <label id="loginUsernameID">Username:</label>
            </div>
            <div className="row mt-3">
              <input
                id="loginUsername"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
              />
            </div>
            <div className="row mt-3">
              <label id="loginPasswordID">Password:</label>
            </div>
            <div className="row mt-3">
              <input
                id="loginPassword"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
              />
            </div>
            <div className="row mt-3">
              <button class="btn btn-primary" id="LoginBtn" onClick={login}>
                Login
              </button>
            </div>
          </div>
        </div>
      )}
      {currentView === "customer" && (
        <div className="container">
          <div id="customerDiv" class="main">
            <div className="row mt-3">
              <h1>myBank</h1>
            </div>
            <div className="row mt-3">
              <input
                id="depositAmount"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="Deposit Amount"
              />
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="depositBtn"
                onClick={() => {
                  deposit(parseInt(depositAmount), username);
                }}
              >
                Deposit
              </button>
            </div>
            <div className="row mt-3">
              <input
                id="withdrawAmount"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="Withdraw Amount"
              />
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="withdrawBtn"
                onClick={() => {
                  withdraw(parseInt(withdrawAmount), username);
                }}
              >
                Withdraw
              </button>
            </div>
            <div className="row mt-3">
              <input
                id="transferAmount"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                placeholder="Transfer Amount"
              />
            </div>
            <div className="row mt-3">
              <input
                id="receiver"
                value={receiver}
                onChange={(e) => setRecevier(e.target.value)}
                placeholder="Receiver Username"
              />
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="transferBtn"
                onClick={() => {
                  transfer(parseInt(transferAmount), username, receiver);
                }}
              >
                Transfer
              </button>
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="CustomerBackBtn"
                onClick={() => setCurrentView("login")}
              >
                Back
              </button>
            </div>
          </div>
        </div>
      )}
      {currentView === "manager" && (
        <div className="container">
          <div id="managerDiv" class="main">
            <div className="row mt-3">
              <h1>myBank</h1>
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="AddCustomerBtn"
                onClick={() => setCurrentView("addCustomer")}
              >
                Add Customer
              </button>
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="DeleteCustomerBtn"
                onClick={() => setCurrentView("deleteCustomer")}
              >
                Delete Customer
              </button>
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="ManagerBackBtn"
                onClick={() => setCurrentView("login")}
              >
                Back
              </button>
            </div>
          </div>
        </div>
      )}
      {currentView === "addCustomer" && (
        <div className="container">
          <div id="addCustomerDiv" class="main">
            <div className="row mt-3">
              <h1>myBank</h1>
            </div>
            <div className="row mt-3">
              <label id="addUsernameID">Username:</label>
            </div>
            <div className="row mt-3">
              <input
                id="addUsername"
                value={addUsername}
                onChange={(e) => setAddUsername(e.target.value)}
                placeholder="Username"
              />
            </div>
            <div className="row mt-3">
              <label id="addPasswordID">Password:</label>
            </div>
            <div className="row mt-3">
              <input
                id="addPassword"
                value={addPassword}
                onChange={(e) => setAddPassword(e.target.value)}
                placeholder="Password"
              />
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="addCustomerBtn"
                onClick={addCustomer}
              >
                Add Customer
              </button>
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="addCustomerBackBtn"
                onClick={() => setCurrentView("manager")}
              >
                Back
              </button>
            </div>
          </div>
        </div>
      )}
      {currentView === "deleteCustomer" && (
        <div className="container">
          <div id="deleteCustomerDiv" class="main">
            <div className="row mt-3">
              <h1>myBank</h1>
            </div>
            <div className="row mt-3">
              <label id="deleteUsernameID">Username:</label>
            </div>
            <div className="row mt-3">
              <input
                id="deleteUsername"
                value={deleteUsername}
                onChange={(e) => setDeleteUsername(e.target.value)}
                placeholder="Username"
              />
            </div>
            <div className="row mt-3">
              <label id="deletePasswordID">Password:</label>
            </div>
            <div className="row mt-3">
              <input
                id="deletePassword"
                value={deletePassword}
                onChange={(e) => setDeletePassword(e.target.value)}
                placeholder="Password"
              />
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="deleteCustomerBtn"
                onClick={deleteCustomer}
              >
                Delete Customer
              </button>
            </div>
            <div className="row mt-3">
              <button
                class="btn btn-primary"
                id="deleteCustomerBackBtn"
                onClick={() => setCurrentView("manager")}
              >
                Back
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
